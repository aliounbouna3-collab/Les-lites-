import { useState, useEffect, useRef } from "react";

// ─── SUPABASE CONFIG ─────────────────────────────────────────────────────────
const SUPABASE_URL = "https://itraeulzkoidnygomxem.supabase.co";
const SUPABASE_KEY = "sb_publishable_Bp2DpaPi2r4pFMDnOisGrQ_Yud5vPn_";
const SERVICE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml0cmFldWx6a29pZG55Z29teGVtIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MDc1MjkzMywiZXhwIjoyMDk2MzI4OTMzfQ.wNArugAic48xasnrxGT3m44emt3vsxhiH22nEvz68Pg";
const REST = `${SUPABASE_URL}/rest/v1`;

const headers = () => ({
  "Content-Type": "application/json",
  "apikey": SERVICE_KEY,
  "Authorization": `Bearer ${SERVICE_KEY}`,
});

// ─── Supabase helpers ─────────────────────────────────────────────────────────
const sb = {
  // Phone-based auth — query users table directly
  async loginByPhone(phone, password) {
    const r = await fetch(
      `${REST}/users?phone=eq.${encodeURIComponent(phone)}&password_hash=eq.${encodeURIComponent(password)}&select=*`,
      { headers: headers() }
    );
    const d = await r.json();
    return Array.isArray(d) && d.length > 0 ? d[0] : null;
  },
  async phoneExists(phone) {
    const r = await fetch(`${REST}/users?phone=eq.${encodeURIComponent(phone)}&select=id`, { headers: headers() });
    const d = await r.json();
    return Array.isArray(d) && d.length > 0;
  },

  // Users
  async getUser(id) {
    const r = await fetch(`${REST}/users?id=eq.${id}&select=*`, { headers: headers() });
    const d = await r.json();
    return d[0];
  },
  async createUser(data) {
    const r = await fetch(`${REST}/users`, {
      method: "POST", headers: { ...headers(), "Prefer": "return=representation" },
      body: JSON.stringify(data),
    });
    return r.json();
  },
  async updateUser(id, data) {
    const r = await fetch(`${REST}/users?id=eq.${id}`, {
      method: "PATCH", headers: { ...headers(), "Prefer": "return=representation" },
      body: JSON.stringify(data),
    });
    return r.json();
  },

  // Subjects
  async getSubjects(bacType) {
    const r = await fetch(
      `${REST}/subjects?is_published=eq.true&bac_types=cs.{"${bacType}"}&order=order_index`,
      { headers: headers() }
    );
    return r.json();
  },

  // Chapters
  async getChapters(subjectId) {
    const r = await fetch(
      `${REST}/chapters?subject_id=eq.${subjectId}&order=order_index`,
      { headers: headers() }
    );
    return r.json();
  },

  // Progress
  async getProgress(userId) {
    const r = await fetch(`${REST}/progress?user_id=eq.${userId}&select=*`, { headers: headers() });
    return r.json();
  },
  async upsertProgress(data) {
    const r = await fetch(`${REST}/progress`, {
      method: "POST",
      headers: { ...headers(), "Prefer": "resolution=merge-duplicates,return=representation" },
      body: JSON.stringify(data),
    });
    return r.json();
  },

  // Exams
  async getExams(subjectId) {
    const r = await fetch(
      `${REST}/exams?subject_id=eq.${subjectId}&is_published=eq.true&order=order_index`,
      { headers: headers() }
    );
    return r.json();
  },
  async getQuestions(examId) {
    const r = await fetch(
      `${REST}/questions?exam_id=eq.${examId}&order=order_index`,
      { headers: headers() }
    );
    return r.json();
  },
  async createSession(data) {
    const r = await fetch(`${REST}/exam_sessions`, {
      method: "POST", headers: { ...headers(), "Prefer": "return=representation" },
      body: JSON.stringify(data),
    });
    const d = await r.json();
    return d[0];
  },
  async updateSession(id, data) {
    const r = await fetch(`${REST}/exam_sessions?id=eq.${id}`, {
      method: "PATCH", headers: { ...headers(), "Prefer": "return=representation" },
      body: JSON.stringify(data),
    });
    return r.json();
  },
  async saveAnswer(data) {
    await fetch(`${REST}/exam_answers`, {
      method: "POST", headers: headers(),
      body: JSON.stringify(data),
    });
  },

  // AI messages
  async getAiMessages(userId, chapterId) {
    const r = await fetch(
      `${REST}/ai_messages?user_id=eq.${userId}&chapter_id=eq.${chapterId}&order=created_at`,
      { headers: headers() }
    );
    return r.json();
  },
  async saveAiMessage(data) {
    await fetch(`${REST}/ai_messages`, {
      method: "POST", headers: headers(),
      body: JSON.stringify(data),
    });
  },

  // Books
  async getBooks() {
    const r = await fetch(`${REST}/books?is_published=eq.true&order=order_index`, { headers: headers() });
    return r.json();
  },

  // Payments
  async submitPayment(data) {
    const r = await fetch(`${REST}/payments`, {
      method: "POST", headers: { ...headers(), "Prefer": "return=representation" },
      body: JSON.stringify(data),
    });
    return r.json();
  },
  async getUserPayments(userId) {
    const r = await fetch(`${REST}/payments?user_id=eq.${userId}&order=submitted_at.desc`, { headers: headers() });
    return r.json();
  },
};

// ─── TRANSLATIONS ─────────────────────────────────────────────────────────────
const T_ALL = {
  fr: {
    welcome:"Bienvenue", tagline:"La plateforme d'excellence pour le Baccalauréat",
    chooseLanguage:"Choisissez votre langue", login:"Se connecter", register:"Créer un compte",
    email:"Adresse e-mail", phone:"Numéro de téléphone", password:"Mot de passe",
    confirmPassword:"Confirmer", fullName:"Nom complet", firstName:"Prénom", lastName:"Nom",
    bacCategory:"Filière du Baccalauréat", next:"Suivant", confirm:"Confirmer",
    otpTitle:"Vérification", otpDesc:"Entrez le code envoyé à votre e-mail",
    enterOtp:"Code de vérification", subjects:"Matières", levelTest:"Test de niveau",
    payment:"Paiement", settings:"Paramètres", chapters:"Chapitres", lessons:"Leçons",
    lessonSummary:"Résumé du cours (PDF)", askAI:"Poser une question à l'IA",
    paymentTitle:"Choisissez votre banque", accountNumber:"Numéro de compte à créditer",
    transactionRef:"Référence de transaction", uploadScreenshot:"Joindre la capture d'écran",
    verifying:"Vérification en cours...", profileSettings:"Profil", changePhone:"Modifier le téléphone",
    changePassword:"Modifier le mot de passe", logout:"Se déconnecter", theme:"Thème",
    back:"Retour", watchLesson:"Regarder", freeContent:"Gratuit", lockedContent:"Verrouillé",
    unlockNow:"Débloquer", aiPlaceholder:"Posez votre question sur ce cours...",
    aiThinking:"L'IA réfléchit...", step:"Étape", of:"sur", createAccount:"Créer un compte",
    haveAccount:"Déjà inscrit ?", loading:"Chargement...", error:"Erreur", retry:"Réessayer",
    noContent:"Aucun contenu disponible", paymentPending:"Paiement en attente de validation",
    paymentValidated:"Compte activé ✓", paymentRejected:"Paiement refusé",
    submitPayment:"Soumettre le paiement", paymentSuccess:"Paiement soumis !",
    paymentSuccessDesc:"Votre paiement est en cours de vérification.", explore:"Explorer →",
    startExam:"Commencer", score:"Score", correct:"Correcte", wrong:"Incorrecte",
    finish:"Terminer", result:"Résultats", yourScore:"Votre score", next_q:"Suivant",
    prev_q:"Précédent", saveProgress:"Progression sauvegardée", watchedVideo:"Vidéo vue ✓",
    amount:"Montant (MRU)", required:"Champ requis", invalidEmail:"E-mail invalide",
    passwordShort:"Minimum 6 caractères", passwordMismatch:"Les mots de passe ne correspondent pas",
    loginError:"Identifiants incorrects", signupError:"Erreur lors de l'inscription",
    noExams:"Aucun examen disponible", free:"Gratuit", locked:"Verrouillé",
    books:"Bibliothèque", booksDesc:"Tous les livres scolaires", openBook:"Ouvrir",
    downloadVideo:"Télécharger", downloaded:"Téléchargé ✓", downloading:"Téléchargement...",
    noBooks:"Aucun livre disponible", videosTab:"Vidéos hors-ligne",
    savedVideos:"Vidéos téléchargées", noSavedVideos:"Aucune vidéo téléchargée",
    deleteVideo:"Supprimer", download:"Télécharger pour hors-ligne",
  },
  ar: {
    welcome:"أهلاً وسهلاً", tagline:"منصة التميز لطلاب البكالوريا",
    chooseLanguage:"اختر لغتك", login:"تسجيل الدخول", register:"إنشاء حساب",
    email:"البريد الإلكتروني", phone:"رقم الهاتف", password:"كلمة السر",
    confirmPassword:"تأكيد", fullName:"الاسم الكامل", firstName:"الاسم", lastName:"اللقب",
    bacCategory:"فئة البكالوريا", next:"التالي", confirm:"تأكيد",
    otpTitle:"التحقق", otpDesc:"أدخل الرمز المرسل إلى بريدك",
    enterOtp:"رمز التحقق", subjects:"المواد", levelTest:"قياس المستوى",
    payment:"الدفع", settings:"الإعدادات", chapters:"الفهارس", lessons:"الدروس",
    lessonSummary:"ملخص الدرس (PDF)", askAI:"اسأل الذكاء الاصطناعي",
    paymentTitle:"اختر البنك", accountNumber:"رقم الحساب للتحويل",
    transactionRef:"رقم المعاملة", uploadScreenshot:"أرفق لقطة الشاشة",
    verifying:"جارٍ التحقق...", profileSettings:"الملف الشخصي",
    changePhone:"تغيير الهاتف", changePassword:"تغيير كلمة السر",
    logout:"تسجيل الخروج", theme:"التصميم", back:"رجوع",
    watchLesson:"مشاهدة", freeContent:"مجاني", lockedContent:"مقفل",
    unlockNow:"افتح الآن", aiPlaceholder:"اسأل عن هذا الدرس...",
    aiThinking:"الذكاء الاصطناعي يفكر...", step:"خطوة", of:"من",
    createAccount:"إنشاء حساب جديد", haveAccount:"لديك حساب؟",
    loading:"جارٍ التحميل...", error:"خطأ", retry:"إعادة المحاولة",
    noContent:"لا يوجد محتوى", paymentPending:"الدفع قيد المراجعة",
    paymentValidated:"الحساب مفعل ✓", paymentRejected:"تم رفض الدفع",
    submitPayment:"إرسال الدفع", paymentSuccess:"تم إرسال الدفع!",
    paymentSuccessDesc:"دفعتك قيد المراجعة.", explore:"استكشف →",
    startExam:"ابدأ", score:"النتيجة", correct:"صحيح", wrong:"خطأ",
    finish:"إنهاء", result:"النتائج", yourScore:"نتيجتك", next_q:"التالي",
    prev_q:"السابق", saveProgress:"تم حفظ التقدم", watchedVideo:"تمت مشاهدة الفيديو ✓",
    amount:"المبلغ (أوقية)", required:"حقل مطلوب", invalidEmail:"البريد غير صحيح",
    passwordShort:"6 أحرف على الأقل", passwordMismatch:"كلمتا السر غير متطابقتين",
    loginError:"بيانات الدخول غير صحيحة", signupError:"خطأ في التسجيل",
    noExams:"لا توجد امتحانات", free:"مجاني", locked:"مقفل",
    books:"المكتبة", booksDesc:"جميع الكتب المدرسية", openBook:"فتح",
    downloadVideo:"تحميل", downloaded:"تم التحميل ✓", downloading:"جارٍ التحميل...",
    noBooks:"لا توجد كتب", videosTab:"فيديوهات بدون إنترنت",
    savedVideos:"الفيديوهات المحملة", noSavedVideos:"لا توجد فيديوهات محملة",
    deleteVideo:"حذف", download:"تحميل للاستخدام بدون إنترنت",
  },
  en: {
    welcome:"Welcome", tagline:"The excellence platform for BAC students",
    chooseLanguage:"Choose your language", login:"Log In", register:"Create Account",
    email:"Email address", phone:"Phone number", password:"Password",
    confirmPassword:"Confirm password", fullName:"Full name", firstName:"First name", lastName:"Last name",
    bacCategory:"BAC Category", next:"Next", confirm:"Confirm",
    otpTitle:"Verification", otpDesc:"Enter the code sent to your email",
    enterOtp:"Verification code", subjects:"Subjects", levelTest:"Level Test",
    payment:"Payment", settings:"Settings", chapters:"Chapters", lessons:"Lessons",
    lessonSummary:"Lesson Summary (PDF)", askAI:"Ask AI",
    paymentTitle:"Choose your bank", accountNumber:"Account number to transfer to",
    transactionRef:"Transaction reference", uploadScreenshot:"Attach screenshot",
    verifying:"Verifying...", profileSettings:"Profile", changePhone:"Change phone",
    changePassword:"Change password", logout:"Log Out", theme:"Theme",
    back:"Back", watchLesson:"Watch", freeContent:"Free", lockedContent:"Locked",
    unlockNow:"Unlock now", aiPlaceholder:"Ask about this lesson...",
    aiThinking:"AI is thinking...", step:"Step", of:"of", createAccount:"Create account",
    haveAccount:"Already registered?", loading:"Loading...", error:"Error", retry:"Retry",
    noContent:"No content available", paymentPending:"Payment pending validation",
    paymentValidated:"Account activated ✓", paymentRejected:"Payment rejected",
    submitPayment:"Submit payment", paymentSuccess:"Payment submitted!",
    paymentSuccessDesc:"Your payment is being verified.", explore:"Explore →",
    startExam:"Start", score:"Score", correct:"Correct", wrong:"Wrong",
    finish:"Finish", result:"Results", yourScore:"Your score", next_q:"Next",
    prev_q:"Previous", saveProgress:"Progress saved", watchedVideo:"Video watched ✓",
    amount:"Amount (MRU)", required:"Required field", invalidEmail:"Invalid email",
    passwordShort:"Minimum 6 characters", passwordMismatch:"Passwords don't match",
    loginError:"Incorrect credentials", signupError:"Registration error",
    noExams:"No exams available", free:"Free", locked:"Locked",
    books:"Library", booksDesc:"All school books", openBook:"Open",
    downloadVideo:"Download", downloaded:"Downloaded ✓", downloading:"Downloading...",
    noBooks:"No books available", videosTab:"Offline Videos",
    savedVideos:"Downloaded videos", noSavedVideos:"No downloaded videos",
    deleteVideo:"Delete", download:"Download for offline use",
  },
};

const BANKS = [
  { id:"bankily",  name:"Bankily",  color:"#00A651", logo:"B",  account:"2234 5678 9012" },
  { id:"masrivi",  name:"Masrivi",  color:"#E4002B", logo:"M",  account:"3345 6789 0123" },
  { id:"sedad",    name:"Sedad",    color:"#1A478A", logo:"S",  account:"4456 7890 1234" },
  { id:"amanty",   name:"Amanty",   color:"#8B5CF6", logo:"Am", account:"5567 8901 2345" },
  { id:"other",    name:"BimBank",  color:"#FF6B00", logo:"Bi", account:"6678 9012 3456" },
  { id:"other",    name:"Click",    color:"#00B4D8", logo:"CL", account:"7789 0123 4567" },
  { id:"other",    name:"BCIPay",   color:"#059669", logo:"BC", account:"8890 1234 5678" },
];

const THEMES = [
  { id:"dark",     bg:"#0A0A0F", accent:"#C9A84C", card:"rgba(255,255,255,0.04)", border:"rgba(255,255,255,0.08)" },
  { id:"midnight", bg:"#0D1B2A", accent:"#4FC3F7", card:"rgba(255,255,255,0.04)", border:"rgba(255,255,255,0.08)" },
  { id:"forest",   bg:"#0F2518", accent:"#4ADE80", card:"rgba(255,255,255,0.04)", border:"rgba(255,255,255,0.08)" },
  { id:"rose",     bg:"#1A0A0F", accent:"#FB7185", card:"rgba(255,255,255,0.04)", border:"rgba(255,255,255,0.08)" },
  { id:"light",    bg:"#F5F3EE", accent:"#B8860B", card:"rgba(0,0,0,0.04)",       border:"rgba(0,0,0,0.1)" },
];

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen]           = useState("lang");          // lang|auth|otp|home
  const [lang, setLang]               = useState("fr");
  const [theme, setTheme]             = useState(THEMES[0]);
  const [authMode, setAuthMode]       = useState("login");         // login|register
  const [regStep, setRegStep]         = useState(1);
  const [activeTab, setActiveTab]     = useState("subjects");
  const [activeSubject, setActiveSubject] = useState(null);
  const [activeChapter, setActiveChapter] = useState(null);
  const [activeExam, setActiveExam]   = useState(null);
  const [examSession, setExamSession] = useState(null);
  const [questions, setQuestions]     = useState([]);
  const [qIndex, setQIndex]           = useState(0);
  const [answers, setAnswers]         = useState({});
  const [examDone, setExamDone]       = useState(false);
  const [selectedBank, setSelectedBank] = useState(null);
  const [payStep, setPayStep]         = useState(1);
  const [payTimer, setPayTimer]       = useState(5);

  // Supabase auth state
  const [token, setToken]             = useState(null);
  const [authUser, setAuthUser]       = useState(null);   // supabase auth user
  const [profile, setProfile]         = useState(null);   // users table row

  // Data
  const [subjects, setSubjects]       = useState([]);
  const [chapters, setChapters]       = useState([]);
  const [aiMessages, setAiMessages]   = useState([]);
  const [progress, setProgress]       = useState([]);
  const [userPayments, setUserPayments] = useState([]);
  const [exams, setExams]             = useState([]);
  const [books, setBooks]             = useState([]);
  const [activeBook, setActiveBook]   = useState(null);
  const [downloadedVideos, setDownloadedVideos] = useState(() => {
    try { return JSON.parse(localStorage.getItem("elites_videos") || "[]"); } catch { return []; }
  });
  const [downloadingId, setDownloadingId] = useState(null);

  // Form state
  const [form, setForm]               = useState({ firstName:"", lastName:"", phone:"", email:"", password:"", confirm:"", bac:"", amount:"" });
  const [transactionRef, setTransactionRef] = useState("");
  const [aiQuestion, setAiQuestion]   = useState("");
  const [aiLoading, setAiLoading]     = useState(false);
  const [loading, setLoading]         = useState(false);
  const [errMsg, setErrMsg]           = useState("");
  const [toast, setToast]             = useState("");

  const T = T_ALL[lang];
  const isRTL = lang === "ar";
  const isDark = !theme.bg.startsWith("#F");
  const textColor = isDark ? "#F0EDE8" : "#1A1710";
  const subColor  = isDark ? "#7A7670" : "#6B6560";

  const S = {
    app:   { width:"100%", maxWidth:430, margin:"0 auto", minHeight:"100vh", background:theme.bg, color:textColor,
              fontFamily:"'Cormorant Garamond','Noto Naskh Arabic',serif", direction:isRTL?"rtl":"ltr", position:"relative" },
    page:  { minHeight:"100vh", display:"flex", flexDirection:"column", padding:"0 22px 110px" },
    head:  { padding:"52px 0 20px" },
    logo:  { fontSize:46, fontWeight:700, color:theme.accent, letterSpacing:-2, lineHeight:1 },
    logoS: { fontSize:11, letterSpacing:6, color:subColor, marginTop:5, textTransform:"uppercase", fontFamily:"sans-serif" },
    title: { fontSize:26, fontWeight:700, lineHeight:1.2 },
    sub:   { fontSize:14, color:subColor, fontFamily:"sans-serif", lineHeight:1.5 },
    card:  { background:theme.card, border:`1px solid ${theme.border}`, borderRadius:14, padding:18, marginBottom:10 },
    inp:   { width:"100%", background:isDark?"rgba(255,255,255,0.06)":"rgba(0,0,0,0.05)",
              border:`1px solid ${theme.border}`, borderRadius:10, padding:"13px 14px",
              fontSize:15, color:textColor, outline:"none", boxSizing:"border-box", marginBottom:10,
              fontFamily:"sans-serif" },
    btn:   { width:"100%", background:theme.accent, color:"#0A0A0F", border:"none",
              borderRadius:10, padding:"15px 22px", fontSize:15, fontWeight:700, cursor:"pointer", fontFamily:"sans-serif" },
    btnO:  { width:"100%", background:"transparent", color:theme.accent, border:`1.5px solid ${theme.accent}`,
              borderRadius:10, padding:"13px 22px", fontSize:14, cursor:"pointer", fontFamily:"sans-serif" },
    back:  { background:"none", border:"none", color:theme.accent, cursor:"pointer", fontSize:13,
              fontFamily:"sans-serif", padding:"6px 0", display:"flex", alignItems:"center", gap:5 },
    tag:   { display:"inline-block", background:theme.accent+"22", color:theme.accent,
              borderRadius:20, padding:"3px 10px", fontSize:11, fontFamily:"sans-serif" },
    nav:   { position:"fixed", bottom:0, left:"50%", transform:"translateX(-50%)", width:"100%", maxWidth:430,
              background:isDark?"rgba(10,10,15,0.96)":"rgba(245,243,238,0.96)", backdropFilter:"blur(20px)",
              borderTop:`1px solid ${theme.border}`, display:"flex", justifyContent:"space-around",
              padding:"10px 0 20px", zIndex:100 },
  };

  // ── Toast ───────────────────────────────────────────────────────────────────
  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(""), 3000); };

  // ── Payment timer ───────────────────────────────────────────────────────────
  useEffect(() => {
    if (payStep === 3) {
      const t = setInterval(() => setPayTimer(p => {
        if (p <= 1) { clearInterval(t); setPayStep(4); return 5; }
        return p - 1;
      }), 1000);
      return () => clearInterval(t);
    }
  }, [payStep]);

  // ── Load subjects when user logs in ─────────────────────────────────────────
  useEffect(() => {
    if (profile) { loadSubjects(); loadBooks(); }
  }, [profile]);

  // ── Load chapters when subject selected ─────────────────────────────────────
  useEffect(() => {
    if (activeSubject) loadChapters(activeSubject.id);
  }, [activeSubject]);

  // ── Load exams when subject selected ────────────────────────────────────────
  useEffect(() => {
    if (activeTab === "leveltest" && activeSubject) loadExams(activeSubject.id);
  }, [activeTab, activeSubject]);

  // ── Load AI messages when chapter selected ──────────────────────────────────
  useEffect(() => {
    if (activeChapter && profile) loadAiMessages();
  }, [activeChapter]);

  // ── Load progress & payments ─────────────────────────────────────────────────
  useEffect(() => {
    if (profile) {
      sb.getProgress(profile.id).then(setProgress);
      sb.getUserPayments(profile.id).then(setUserPayments);
    }
  }, [profile]);

  async function loadSubjects() {
    setLoading(true);
    const data = await sb.getSubjects(profile.bac_type);
    setSubjects(Array.isArray(data) ? data : []);
    setLoading(false);
  }
  async function loadChapters(subjectId) {
    setLoading(true);
    const data = await sb.getChapters(subjectId);
    setChapters(Array.isArray(data) ? data : []);
    setLoading(false);
  }
  async function loadExams(subjectId) {
    const data = await sb.getExams(subjectId);
    setExams(Array.isArray(data) ? data : []);
  }
  async function loadBooks() {
    const data = await sb.getBooks();
    setBooks(Array.isArray(data) ? data : []);
  }
  async function downloadVideo(chapter) {
    if (!chapter.video_url) return;
    setDownloadingId(chapter.id);
    try {
      const res = await fetch(chapter.video_url, { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${token}` } });
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement("a");
      a.href     = url;
      a.download = `${chapter.title_fr || "video"}.mp4`;
      a.click();
      URL.revokeObjectURL(url);
      const saved = [...downloadedVideos, { id: chapter.id, title_fr: chapter.title_fr, title_ar: chapter.title_ar, savedAt: new Date().toISOString() }];
      setDownloadedVideos(saved);
      try { localStorage.setItem("elites_videos", JSON.stringify(saved)); } catch {}
      showToast(T.downloaded);
    } catch { showToast(T.error); }
    setDownloadingId(null);
  }
  function deleteDownload(id) {
    const saved = downloadedVideos.filter(v => v.id !== id);
    setDownloadedVideos(saved);
    try { localStorage.setItem("elites_videos", JSON.stringify(saved)); } catch {}
  }
  async function loadAiMessages() {
    const data = await sb.getAiMessages(profile.id, activeChapter.id);
    setAiMessages(Array.isArray(data) ? data : []);
  }

  // ── AUTH (Phone + Password) ───────────────────────────────────────────────────
  async function handleLogin() {
    setErrMsg(""); setLoading(true);
    try {
      const p = await sb.loginByPhone(form.phone, form.password);
      setLoading(false);
      if (p) { setProfile(p); setLang(p.language || lang); setScreen("home"); }
      else setErrMsg(T.loginError);
    } catch(e) { setLoading(false); setErrMsg(T.loginError); }
  }

  async function handleRegister() {
    if (regStep < 4) { setRegStep(s => s + 1); return; }
    setErrMsg(""); setLoading(true);
    try {
      // Check phone not already used
      const exists = await sb.phoneExists(form.phone);
      if (exists) { setLoading(false); setErrMsg("Ce numéro est déjà utilisé"); return; }
      // Create user directly in users table (no Supabase Auth)
      const newUser = {
        id: crypto.randomUUID(),
        first_name: form.firstName || "Élève",
        last_name: form.lastName || "",
        phone: form.phone,
        password_hash: form.password,
        bac_type: form.bac || "C",
        language: lang,
        is_paid: false,
      };
      const result = await sb.createUser(newUser);
      setLoading(false);
      const p = Array.isArray(result) ? result[0] : result;
      if (p && p.id) { setProfile(p); setLang(p.language || lang); setScreen("home"); }
      else setErrMsg(T.signupError);
    } catch(e) { setLoading(false); setErrMsg(T.signupError); }
  }

  async function handleLogout() {
    setProfile(null);
    setSubjects([]); setChapters([]); setAiMessages([]);
    setActiveSubject(null); setActiveChapter(null);
    setScreen("lang"); setActiveTab("subjects");
  }

  // ── Progress update ──────────────────────────────────────────────────────────
  async function markVideoWatched(chapterId) {
    if (!profile) return;
    await sb.upsertProgress({ user_id: profile.id, chapter_id: chapterId, video_watched: true });
    const updated = await sb.getProgress(profile.id);
    setProgress(updated);
    showToast(T.watchedVideo);
  }

  // ── Payment submit ────────────────────────────────────────────────────────────
  async function submitPayment() {
    if (!transactionRef) return;
    setLoading(true);
    await sb.submitPayment({
      user_id: profile.id,
      amount: parseInt(form.amount) || 0,
      method: selectedBank.id,
      transaction_ref: transactionRef,
      proof_url: "pending_upload",
      status: "pending",
    });
    setLoading(false);
    setPayStep(3);
  }

  // ── AI Q&A ────────────────────────────────────────────────────────────────────
  async function handleAskAI() {
    if (!aiQuestion.trim() || !activeChapter) return;
    const q = aiQuestion; setAiQuestion(""); setAiLoading(true);
    const newMsg = { role:"user", content:q };
    setAiMessages(m => [...m, newMsg]);
    await sb.saveAiMessage({ user_id:profile.id, chapter_id:activeChapter.id, role:"user", content:q });

    try {
      const history = [...aiMessages, newMsg].map(m => ({ role:m.role, content:m.content }));
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514", max_tokens:1000,
          system:`Tu es un assistant pédagogique pour élèves du Baccalauréat mauritanien. Le cours actuel est "${activeChapter["title_"+lang] || activeChapter.title_fr}" dans la matière "${activeSubject?.["name_"+lang] || ""}". Réponds uniquement aux questions liées à ce cours. Sois concis et pédagogique. Réponds en ${lang==="ar"?"arabe":lang==="fr"?"français":"anglais"}.`,
          messages: history.slice(-10),
        }),
      });
      const d = await res.json();
      const reply = d.content?.[0]?.text || "...";
      setAiMessages(m => [...m, { role:"assistant", content:reply }]);
      await sb.saveAiMessage({ user_id:profile.id, chapter_id:activeChapter.id, role:"assistant", content:reply });
    } catch { setAiMessages(m => [...m, { role:"assistant", content:"Erreur. Réessayez." }]); }
    setAiLoading(false);
  }

  // ── Exam ──────────────────────────────────────────────────────────────────────
  async function startExam(exam) {
    setActiveExam(exam);
    const qs = await sb.getQuestions(exam.id);
    setQuestions(Array.isArray(qs) ? qs : []);
    setQIndex(0); setAnswers({}); setExamDone(false);
    const session = await sb.createSession({ user_id:profile.id, exam_id:exam.id, status:"in_progress" });
    setExamSession(session);
  }
  async function submitAnswer(q, answer) {
    const isCorrect = answer === q.correct_answer;
    const newAnswers = { ...answers, [q.id]: { answer, isCorrect } };
    setAnswers(newAnswers);
    await sb.saveAnswer({ session_id:examSession.id, question_id:q.id, user_answer:answer, is_correct:isCorrect, points_earned: isCorrect ? q.points : 0 });
    if (qIndex < questions.length - 1) setQIndex(i => i + 1);
    else {
      const score = Object.values(newAnswers).filter(a => a.isCorrect).length;
      const total = questions.length;
      await sb.updateSession(examSession.id, { status:"completed", score, total_points:total, percentage:(score/total*100).toFixed(2), completed_at: new Date().toISOString() });
      setExamDone(true);
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────────
  const getChapterProgress = (chId) => progress.find(p => p.chapter_id === chId);
  const isPaid = profile?.is_paid || userPayments.some(p => p.status === "validated");
  const latestPayment = userPayments[0];

  // ── RENDER SCREENS ────────────────────────────────────────────────────────────

  // Language select
  if (screen === "lang") return (
    <div style={S.app}>
      <div style={{ ...S.page, justifyContent:"center", alignItems:"center", padding:"40px 24px" }}>
        <div style={{ textAlign:"center", marginBottom:56 }}>
          <div style={S.logo}>E</div>
          <div style={S.logoS}>Les Élites</div>
          <div style={{ width:36, height:2, background:theme.accent, margin:"14px auto" }} />
          <div style={{ fontSize:15, color:subColor, fontFamily:"sans-serif" }}>اختر / Choisissez / Choose</div>
        </div>
        {[{c:"fr",l:"Français",f:"🇫🇷"},{c:"ar",l:"العربية",f:"🇲🇷"},{c:"en",l:"English",f:"🇬🇧"}].map(x => (
          <div key={x.c} onClick={() => { setLang(x.c); setScreen("auth"); }}
            style={{ ...S.card, cursor:"pointer", display:"flex", alignItems:"center", gap:14, width:"100%", boxSizing:"border-box" }}>
            <span style={{fontSize:28}}>{x.f}</span>
            <span style={{fontSize:18,fontWeight:600}}>{x.l}</span>
            <span style={{marginLeft:"auto",color:theme.accent,fontSize:18}}>›</span>
          </div>
        ))}
      </div>
    </div>
  );

  // Auth
  if (screen === "auth") return (
    <div style={S.app}>
      <div style={S.page}>
        <div style={S.head}>
          <div style={S.logo}>E</div>
          <div style={S.logoS}>Les Élites</div>
        </div>
        <div style={{display:"flex",gap:8,marginBottom:28}}>
          {["login","register"].map(m => (
            <button key={m} onClick={() => { setAuthMode(m); setRegStep(1); setErrMsg(""); }}
              style={{ flex:1, padding:12, borderRadius:9, border:"none", cursor:"pointer",
                background:authMode===m?theme.accent:theme.card, color:authMode===m?"#0A0A0F":subColor,
                fontWeight:600, fontSize:14, fontFamily:"sans-serif" }}>
              {m==="login"?T.login:T.register}
            </button>
          ))}
        </div>

        {authMode === "login" ? (
          <>
            <input style={S.inp} placeholder={T.phone} type="tel" value={form.phone}
              onChange={e=>setForm(f=>({...f,phone:e.target.value}))} />
            <input style={S.inp} placeholder={T.password} type="password" value={form.password}
              onChange={e=>setForm(f=>({...f,password:e.target.value}))} />
            {errMsg && <div style={{color:"#F87171",fontSize:13,fontFamily:"sans-serif",marginBottom:10}}>{errMsg}</div>}
            <button style={S.btn} onClick={handleLogin} disabled={loading}>
              {loading ? T.loading : T.login}
            </button>
          </>
        ) : (
          <>
            <div style={{...S.tag,marginBottom:14}}>{T.step} {regStep} {T.of} 4</div>
            {regStep===1 && <>
              <div style={{...S.title,fontSize:20,marginBottom:16}}>{T.firstName}</div>
              <input style={S.inp} placeholder={T.firstName} value={form.firstName}
                onChange={e=>setForm(f=>({...f,firstName:e.target.value}))} />
              <input style={S.inp} placeholder={T.lastName} value={form.lastName}
                onChange={e=>setForm(f=>({...f,lastName:e.target.value}))} />
            </>}
            {regStep===2 && <>
              <div style={{...S.title,fontSize:20,marginBottom:16}}>{T.phone}</div>
              <input style={S.inp} placeholder="+222 XX XX XX XX" type="tel" value={form.phone}
                onChange={e=>setForm(f=>({...f,phone:e.target.value}))} />
            </>}
            {regStep===3 && <>
              <div style={{...S.title,fontSize:20,marginBottom:16}}>{T.password}</div>
              <input style={S.inp} type="password" placeholder={T.password} value={form.password}
                onChange={e=>setForm(f=>({...f,password:e.target.value}))} />
              <input style={S.inp} type="password" placeholder={T.confirmPassword} value={form.confirm}
                onChange={e=>setForm(f=>({...f,confirm:e.target.value}))} />
            </>}
            {regStep===4 && <>
              <div style={{...S.title,fontSize:20,marginBottom:16}}>{T.bacCategory}</div>
              {["C","D","A"].map(b => (
                <div key={b} onClick={()=>setForm(f=>({...f,bac:b}))}
                  style={{...S.card,cursor:"pointer",borderColor:form.bac===b?theme.accent:theme.border,
                    display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <div>
                    <div style={{fontWeight:700,fontSize:17}}>BAC : {b}</div>
                    <div style={{color:subColor,fontSize:12,fontFamily:"sans-serif",marginTop:3}}>
                      {b==="A"?"Lettres & Sciences Humaines":b==="C"?"Sciences Exactes":"Sciences Naturelles"}
                    </div>
                  </div>
                  <div style={{width:22,height:22,borderRadius:"50%",border:`2px solid ${form.bac===b?theme.accent:theme.border}`,
                    background:form.bac===b?theme.accent:"transparent"}} />
                </div>
              ))}
            </>}
            {errMsg && <div style={{color:"#F87171",fontSize:13,fontFamily:"sans-serif",marginBottom:10}}>{errMsg}</div>}
            <div style={{display:"flex",gap:8,marginTop:12}}>
              {regStep>1 && <button style={{...S.btnO,flex:0.5}} onClick={()=>setRegStep(s=>s-1)}>{T.back}</button>}
              <button style={{...S.btn,flex:1}} onClick={handleRegister} disabled={loading}>
                {loading?T.loading:regStep===4?T.confirm:T.next}
              </button>
            </div>
          </>
        )}
        <div style={{textAlign:"center",marginTop:18,color:subColor,fontSize:13,fontFamily:"sans-serif"}}>
          <span onClick={()=>{setAuthMode(authMode==="login"?"register":"login");setErrMsg("");setRegStep(1);}}
            style={{color:theme.accent,cursor:"pointer"}}>
            {authMode==="login"?T.createAccount:T.haveAccount}
          </span>
        </div>
      </div>
    </div>
  );

  // ── HOME ──────────────────────────────────────────────────────────────────────
  const navTabs = [
    {id:"subjects",  icon:"📚", label:T.subjects},
    {id:"books",     icon:"📖", label:T.books},
    {id:"leveltest", icon:"📊", label:T.levelTest},
    {id:"payment",   icon:"💳", label:T.payment},
    {id:"settings",  icon:"⚙️",  label:T.settings},
  ];

  return (
    <div style={S.app}>
      {/* Toast */}
      {toast && (
        <div style={{ position:"fixed", top:20, left:"50%", transform:"translateX(-50%)", background:theme.accent,
          color:"#0A0A0F", borderRadius:20, padding:"10px 20px", fontSize:13, fontFamily:"sans-serif",
          fontWeight:700, zIndex:999, whiteSpace:"nowrap" }}>
          {toast}
        </div>
      )}

      <div style={S.page}>

        {/* ══ SUBJECTS TAB ══════════════════════════════════════════════════════ */}
        {activeTab==="subjects" && !activeSubject && (
          <>
            <div style={S.head}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                <div>
                  <div style={{fontSize:12,color:subColor,fontFamily:"sans-serif",letterSpacing:1}}>
                    BAC : {profile?.bac_type} · {profile?.first_name}
                  </div>
                  <div style={{...S.title,marginTop:4}}>{T.subjects}</div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{fontSize:28,fontWeight:700,color:theme.accent}}>E</div>
                  <div style={{fontSize:8,color:subColor,fontFamily:"sans-serif",letterSpacing:2}}>ÉLITES</div>
                </div>
              </div>
              {!isPaid && (
                <div onClick={()=>setActiveTab("payment")}
                  style={{...S.card,marginTop:14,borderColor:theme.accent+"44",cursor:"pointer",
                    display:"flex",alignItems:"center",gap:10,padding:12}}>
                  <span style={{fontSize:20}}>🔓</span>
                  <span style={{fontSize:13,fontFamily:"sans-serif",color:theme.accent,fontWeight:600}}>
                    {latestPayment?.status==="pending" ? T.paymentPending : T.unlockNow + " →"}
                  </span>
                </div>
              )}
            </div>
            {loading && <div style={{textAlign:"center",color:subColor,fontFamily:"sans-serif",padding:40}}>{T.loading}</div>}
            {!loading && subjects.length===0 && (
              <div style={{textAlign:"center",color:subColor,fontFamily:"sans-serif",padding:40}}>
                {T.noContent}
                <br/><button style={{...S.btn,marginTop:16,width:"auto",padding:"10px 20px"}} onClick={loadSubjects}>{T.retry}</button>
              </div>
            )}
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              {subjects.map(s => (
                <div key={s.id} onClick={()=>setActiveSubject(s)}
                  style={{...S.card,cursor:"pointer",textAlign:"center",padding:"20px 10px",position:"relative",overflow:"hidden"}}>
                  <div style={{position:"absolute",top:0,left:0,right:0,height:3,background:theme.accent,opacity:0.5}}/>
                  <div style={{fontSize:28,marginBottom:8}}>{s.emoji}</div>
                  <div style={{fontSize:12,fontWeight:600,lineHeight:1.3}}>
                    {lang==="ar"?s.name_ar:s.name_fr}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Subject → Chapters */}
        {activeTab==="subjects" && activeSubject && !activeChapter && (
          <>
            <div style={{...S.head}}>
              <button style={S.back} onClick={()=>{setActiveSubject(null);setChapters([]);}}>← {T.back}</button>
              <div style={{...S.title,marginTop:8}}>{lang==="ar"?activeSubject.name_ar:activeSubject.name_fr}</div>
              <div style={{...S.tag,marginTop:6}}>BAC : {profile?.bac_type}</div>
            </div>
            {loading && <div style={{textAlign:"center",color:subColor,fontFamily:"sans-serif",padding:20}}>{T.loading}</div>}
            {chapters.map(ch => {
              const prog = getChapterProgress(ch.id);
              const canAccess = ch.is_free || isPaid;
              return (
                <div key={ch.id} onClick={()=>canAccess&&setActiveChapter(ch)}
                  style={{...S.card,cursor:canAccess?"pointer":"default",display:"flex",justifyContent:"space-between",alignItems:"center",
                    opacity:canAccess?1:0.6}}>
                  <div style={{flex:1}}>
                    <div style={{fontSize:14,fontWeight:600}}>
                      {lang==="ar"?ch.title_ar:ch.title_fr}
                    </div>
                    <div style={{fontSize:11,color:subColor,fontFamily:"sans-serif",marginTop:3,display:"flex",gap:8}}>
                      {ch.duration_min?`${ch.duration_min} min`:""}
                      {ch.is_free ? <span style={{color:"#4ADE80"}}>{T.free}</span> : <span style={{color:theme.accent}}>{isPaid?"":`🔒 ${T.locked}`}</span>}
                    </div>
                    {prog && (
                      <div style={{marginTop:6,height:3,background:theme.border,borderRadius:2,overflow:"hidden"}}>
                        <div style={{width:`${prog.percent}%`,height:"100%",background:theme.accent,borderRadius:2}}/>
                      </div>
                    )}
                  </div>
                  {canAccess && <div style={{color:theme.accent,fontSize:18,marginLeft:10}}>›</div>}
                </div>
              );
            })}
          </>
        )}

        {/* Chapter view */}
        {activeTab==="subjects" && activeChapter && (
          <>
            <div style={{...S.head}}>
              <button style={S.back} onClick={()=>setActiveChapter(null)}>← {T.back}</button>
              <div style={{...S.title,marginTop:8,fontSize:18}}>
                {lang==="ar"?activeChapter.title_ar:activeChapter.title_fr}
              </div>
            </div>

            {/* Video */}
            <div style={{background:"#000",borderRadius:14,aspectRatio:"16/9",display:"flex",alignItems:"center",
              justifyContent:"center",marginBottom:8,position:"relative",overflow:"hidden"}}>
              {activeChapter.video_url ? (
                <iframe src={activeChapter.video_url} style={{width:"100%",height:"100%",border:"none"}}
                  allow="autoplay" onLoad={()=>markVideoWatched(activeChapter.id)} />
              ) : (
                <>
                  <div style={{position:"absolute",inset:0,background:"linear-gradient(135deg,#1a1a2e,#16213e)"}}/>
                  <div style={{position:"relative",textAlign:"center"}}>
                    <div style={{width:52,height:52,borderRadius:"50%",background:theme.accent,display:"flex",
                      alignItems:"center",justifyContent:"center",margin:"0 auto 10px",fontSize:20}}>▶</div>
                    <div style={{color:"rgba(255,255,255,0.5)",fontSize:12,fontFamily:"sans-serif"}}>{T.watchLesson}</div>
                  </div>
                </>
              )}
            </div>
            {/* Download video button */}
            {activeChapter.video_url && (
              <button
                onClick={()=>downloadVideo(activeChapter)}
                disabled={downloadingId===activeChapter.id || downloadedVideos.some(v=>v.id===activeChapter.id)}
                style={{width:"100%",display:"flex",alignItems:"center",justifyContent:"center",gap:8,
                  background:downloadedVideos.some(v=>v.id===activeChapter.id)?"#4ADE8022":theme.card,
                  border:`1px solid ${downloadedVideos.some(v=>v.id===activeChapter.id)?"#4ADE80":theme.border}`,
                  borderRadius:10,padding:"11px 16px",marginBottom:12,cursor:"pointer",
                  color:downloadedVideos.some(v=>v.id===activeChapter.id)?"#4ADE80":textColor,
                  fontSize:13,fontFamily:"sans-serif",fontWeight:600}}>
                <span>{downloadedVideos.some(v=>v.id===activeChapter.id)?"✓":downloadingId===activeChapter.id?"⏳":"⬇️"}</span>
                {downloadedVideos.some(v=>v.id===activeChapter.id) ? T.downloaded
                  : downloadingId===activeChapter.id ? T.downloading : T.download}
              </button>
            )}

            {/* PDF */}
            {(activeChapter.pdf_course_url || activeChapter.pdf_fiche_url) && (
              <div style={{display:"flex",gap:8,marginBottom:14}}>
                {activeChapter.pdf_course_url && (
                  <a href={activeChapter.pdf_course_url} target="_blank" rel="noreferrer"
                    style={{...S.card,flex:1,display:"flex",alignItems:"center",gap:10,textDecoration:"none",color:textColor,marginBottom:0}}>
                    <span style={{fontSize:28}}>📄</span>
                    <div>
                      <div style={{fontWeight:600,fontSize:13}}>{T.lessonSummary}</div>
                      <div style={{fontSize:11,color:subColor,fontFamily:"sans-serif"}}>PDF ↓</div>
                    </div>
                  </a>
                )}
              </div>
            )}

            {/* AI Q&A */}
            <div style={S.card}>
              <div style={{fontWeight:700,marginBottom:12,display:"flex",alignItems:"center",gap:8}}>
                <span style={{fontSize:18}}>🤖</span> {T.askAI}
              </div>
              <div style={{maxHeight:260,overflowY:"auto",marginBottom:10}}>
                {aiMessages.map((m,i) => (
                  <div key={i} style={{marginBottom:10,
                    display:"flex",flexDirection:m.role==="user"?"row-reverse":"row",gap:8,alignItems:"flex-start"}}>
                    <div style={{fontSize:18}}>{m.role==="user"?"👤":"🤖"}</div>
                    <div style={{background:m.role==="user"?theme.accent+"22":theme.card,borderRadius:10,padding:"10px 12px",
                      fontSize:13,lineHeight:1.6,fontFamily:"sans-serif",maxWidth:"85%",
                      border:`1px solid ${m.role==="user"?theme.accent+"44":theme.border}`}}>
                      {m.content}
                    </div>
                  </div>
                ))}
                {aiLoading && <div style={{color:subColor,fontFamily:"sans-serif",fontSize:13}}>⏳ {T.aiThinking}</div>}
              </div>
              <div style={{display:"flex",gap:8}}>
                <input value={aiQuestion} onChange={e=>setAiQuestion(e.target.value)}
                  onKeyDown={e=>e.key==="Enter"&&handleAskAI()}
                  placeholder={T.aiPlaceholder}
                  style={{...S.inp,marginBottom:0,flex:1,fontSize:13}}/>
                <button onClick={handleAskAI} style={{...S.btn,width:"auto",padding:"12px 16px",borderRadius:9}}>→</button>
              </div>
            </div>
          </>
        )}

        {/* ══ LEVEL TEST TAB ════════════════════════════════════════════════════ */}
        {activeTab==="leveltest" && !activeSubject && (
          <>
            <div style={S.head}>
              <div style={S.title}>{T.levelTest}</div>
              <div style={{...S.sub,marginTop:6}}>Choisissez une matière</div>
            </div>
            {subjects.map(s => (
              <div key={s.id} onClick={()=>{setActiveSubject(s);loadExams(s.id);}}
                style={{...S.card,display:"flex",alignItems:"center",gap:12,cursor:"pointer"}}>
                <span style={{fontSize:24}}>{s.emoji}</span>
                <div style={{fontWeight:600,fontSize:14}}>{lang==="ar"?s.name_ar:s.name_fr}</div>
                <span style={{marginLeft:"auto",color:theme.accent}}>›</span>
              </div>
            ))}
          </>
        )}

        {activeTab==="leveltest" && activeSubject && !activeExam && (
          <>
            <div style={S.head}>
              <button style={S.back} onClick={()=>{setActiveSubject(null);setExams([]);}}>← {T.back}</button>
              <div style={{...S.title,marginTop:8}}>{lang==="ar"?activeSubject.name_ar:activeSubject.name_fr}</div>
            </div>
            {exams.length===0 && <div style={{color:subColor,fontFamily:"sans-serif",padding:20}}>{T.noExams}</div>}
            {exams.map(ex => (
              <div key={ex.id} style={S.card}>
                <div style={{fontWeight:600,fontSize:15,marginBottom:4}}>{lang==="ar"?ex.title_ar:ex.title_fr}</div>
                <div style={{color:subColor,fontSize:12,fontFamily:"sans-serif",marginBottom:12}}>
                  {ex.duration_min} min · {ex.total_points} pts · {ex.difficulty}
                </div>
                <button style={{...S.btn,padding:"10px"}} onClick={()=>startExam(ex)}>{T.startExam}</button>
              </div>
            ))}
          </>
        )}

        {activeTab==="leveltest" && activeExam && !examDone && questions.length>0 && (
          <>
            <div style={S.head}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <button style={S.back} onClick={()=>{setActiveExam(null);setQuestions([]);}}>{T.back}</button>
                <div style={{...S.tag}}>{qIndex+1}/{questions.length}</div>
              </div>
              <div style={{height:4,background:theme.border,borderRadius:2,marginTop:12,overflow:"hidden"}}>
                <div style={{width:`${((qIndex+1)/questions.length)*100}%`,height:"100%",background:theme.accent,transition:"width 0.3s"}}/>
              </div>
            </div>
            {(() => {
              const q = questions[qIndex];
              if (!q) return null;
              const opts = q.options || (q.type==="true_false"?{A:"Vrai",B:"Faux"}:{});
              const answered = answers[q.id];
              return (
                <>
                  <div style={{...S.card,marginBottom:16}}>
                    <div style={{fontSize:15,fontWeight:600,lineHeight:1.5}}>
                      {lang==="ar"?q.question_ar:q.question_fr}
                    </div>
                    {q.hint_fr && <div style={{color:subColor,fontSize:12,fontFamily:"sans-serif",marginTop:8}}>
                      💡 {lang==="ar"?q.hint_ar:q.hint_fr}
                    </div>}
                  </div>
                  {Object.entries(opts).map(([k,v]) => {
                    const isSelected = answered?.answer===k;
                    const isCorrect  = k===q.correct_answer;
                    let bg = theme.card, border = theme.border;
                    if (answered) { if (isCorrect) { bg="#4ADE8022"; border="#4ADE80"; } else if (isSelected) { bg="#F8717122"; border="#F87171"; } }
                    return (
                      <div key={k} onClick={()=>!answered&&submitAnswer(q,k)}
                        style={{...S.card,cursor:answered?"default":"pointer",background:bg,borderColor:border,
                          display:"flex",alignItems:"center",gap:12,marginBottom:8}}>
                        <div style={{width:28,height:28,borderRadius:"50%",border:`2px solid ${border}`,
                          display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,fontSize:13,
                          background:isSelected||isCorrect?border:"transparent",color:isSelected||isCorrect?"#0A0A0F":textColor}}>
                          {k}
                        </div>
                        <span style={{fontSize:14,fontFamily:"sans-serif"}}>{v}</span>
                        {answered && isCorrect && <span style={{marginLeft:"auto"}}>✅</span>}
                        {answered && isSelected && !isCorrect && <span style={{marginLeft:"auto"}}>❌</span>}
                      </div>
                    );
                  })}
                  {answered && q.explanation_fr && (
                    <div style={{...S.card,borderColor:theme.accent+"44",marginTop:4}}>
                      <div style={{fontSize:12,fontFamily:"sans-serif",color:subColor,marginBottom:4}}>Explication</div>
                      <div style={{fontSize:13,lineHeight:1.5,fontFamily:"sans-serif"}}>
                        {lang==="ar"?q.explanation_ar:q.explanation_fr}
                      </div>
                    </div>
                  )}
                </>
              );
            })()}
          </>
        )}

        {activeTab==="leveltest" && examDone && (
          <div style={{textAlign:"center",padding:"60px 0"}}>
            <div style={{fontSize:60,marginBottom:16}}>🎯</div>
            <div style={{...S.title,fontSize:22}}>{T.result}</div>
            <div style={{fontSize:48,fontWeight:700,color:theme.accent,margin:"20px 0"}}>
              {Object.values(answers).filter(a=>a.isCorrect).length}/{questions.length}
            </div>
            <div style={{color:subColor,fontFamily:"sans-serif",fontSize:15}}>{T.yourScore}</div>
            <button style={{...S.btn,marginTop:32,width:"auto",padding:"12px 28px"}}
              onClick={()=>{setActiveExam(null);setExamDone(false);setQuestions([]);setActiveSubject(null);}}>
              {T.back}
            </button>
          </div>
        )}

        {/* ══ BOOKS TAB ════════════════════════════════════════════════════════ */}
        {activeTab==="books" && !activeBook && (
          <>
            <div style={S.head}>
              <div style={S.title}>{T.books}</div>
              <div style={{...S.sub,marginTop:6}}>{T.booksDesc}</div>
            </div>
            {books.length===0 && (
              <div style={{textAlign:"center",color:subColor,fontFamily:"sans-serif",padding:40}}>
                {T.noBooks}
              </div>
            )}
            {books.map(book => (
              <div key={book.id} style={{...S.card,display:"flex",alignItems:"center",gap:14,cursor:"pointer"}}
                onClick={()=>setActiveBook(book)}>
                <div style={{width:52,height:64,borderRadius:8,background:theme.accent+"33",
                  border:`2px solid ${theme.accent}44`,display:"flex",alignItems:"center",
                  justifyContent:"center",fontSize:24,flexShrink:0}}>
                  📗
                </div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontWeight:700,fontSize:14,lineHeight:1.3}}>
                    {lang==="ar"?book.title_ar||book.title_fr:book.title_fr}
                  </div>
                  {book.subject_name && (
                    <div style={{...S.tag,marginTop:5}}>
                      {lang==="ar"?book.subject_name_ar||book.subject_name:book.subject_name}
                    </div>
                  )}
                  <div style={{fontSize:11,color:subColor,fontFamily:"sans-serif",marginTop:4}}>
                    {book.is_free ? <span style={{color:"#4ADE80"}}>{T.free}</span>
                      : isPaid ? <span style={{color:theme.accent}}>✓ {T.freeContent}</span>
                      : <span style={{color:"#F87171"}}>🔒 {T.locked}</span>}
                  </div>
                </div>
                <div style={{color:theme.accent,fontSize:18}}>›</div>
              </div>
            ))}

            {/* Downloaded Videos section */}
            <div style={{marginTop:28}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:12}}>
                <span style={{fontSize:18}}>⬇️</span>
                <div style={{fontSize:14,fontWeight:700}}>{T.savedVideos}</div>
              </div>
              {downloadedVideos.length===0 ? (
                <div style={{...S.card,textAlign:"center",color:subColor,fontFamily:"sans-serif",fontSize:13,padding:24}}>
                  {T.noSavedVideos}
                </div>
              ) : downloadedVideos.map(v => (
                <div key={v.id} style={{...S.card,display:"flex",alignItems:"center",gap:12}}>
                  <span style={{fontSize:20}}>🎬</span>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13,fontWeight:600}}>{lang==="ar"?v.title_ar||v.title_fr:v.title_fr}</div>
                    <div style={{fontSize:11,color:subColor,fontFamily:"sans-serif",marginTop:2}}>
                      {new Date(v.savedAt).toLocaleDateString()}
                    </div>
                  </div>
                  <button onClick={()=>deleteDownload(v.id)}
                    style={{background:"#F8717122",color:"#F87171",border:"none",borderRadius:8,
                      padding:"6px 12px",cursor:"pointer",fontSize:12,fontFamily:"sans-serif"}}>
                    {T.deleteVideo}
                  </button>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Book reader */}
        {activeTab==="books" && activeBook && (
          <>
            <div style={{...S.head}}>
              <button style={S.back} onClick={()=>setActiveBook(null)}>← {T.back}</button>
              <div style={{...S.title,marginTop:8,fontSize:18}}>
                {lang==="ar"?activeBook.title_ar||activeBook.title_fr:activeBook.title_fr}
              </div>
            </div>
            {(activeBook.is_free || isPaid) ? (
              activeBook.pdf_url ? (
                <div style={{borderRadius:14,overflow:"hidden",border:`1px solid ${theme.border}`,background:"#000"}}>
                  <iframe
                    src={`https://docs.google.com/gview?url=${encodeURIComponent(activeBook.pdf_url)}&embedded=true`}
                    style={{width:"100%",height:"75vh",border:"none"}}
                    title={activeBook.title_fr}
                  />
                </div>
              ) : (
                <div style={{...S.card,textAlign:"center",padding:40,color:subColor,fontFamily:"sans-serif"}}>
                  {T.noContent}
                </div>
              )
            ) : (
              <div style={{...S.card,textAlign:"center",padding:40}}>
                <div style={{fontSize:48,marginBottom:16}}>🔒</div>
                <div style={{fontWeight:600,marginBottom:8}}>{T.lockedContent}</div>
                <button style={{...S.btn,width:"auto",padding:"12px 24px",marginTop:8}}
                  onClick={()=>{setActiveBook(null);setActiveTab("payment");}}>
                  {T.unlockNow} →
                </button>
              </div>
            )}
          </>
        )}

        {/* ══ PAYMENT TAB ═══════════════════════════════════════════════════════ */}
        {activeTab==="payment" && (
          <>
            <div style={S.head}>
              <div style={S.title}>{T.payment}</div>
              {isPaid
                ? <div style={{...S.sub,marginTop:8,color:"#4ADE80"}}>{T.paymentValidated}</div>
                : latestPayment?.status==="pending"
                  ? <div style={{...S.sub,marginTop:8,color:theme.accent}}>{T.paymentPending}</div>
                  : <div style={{...S.sub,marginTop:8}}>{T.paymentTitle}</div>
              }
            </div>

            {!isPaid && !selectedBank && (
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {BANKS.map((b,i) => (
                  <div key={i} onClick={()=>{setSelectedBank(b);setPayStep(1);setTransactionRef("");}}
                    style={{...S.card,cursor:"pointer",textAlign:"center",padding:18}}>
                    <div style={{width:44,height:44,borderRadius:12,background:b.color+"22",border:`2px solid ${b.color}44`,
                      display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 8px",
                      fontWeight:800,fontSize:14,color:b.color}}>
                      {b.logo}
                    </div>
                    <div style={{fontSize:12,fontWeight:600}}>{b.name}</div>
                  </div>
                ))}
              </div>
            )}

            {!isPaid && selectedBank && payStep===1 && (
              <>
                <button style={S.back} onClick={()=>setSelectedBank(null)}>← {T.back}</button>
                <div style={{...S.card,textAlign:"center",margin:"10px 0 14px",borderColor:selectedBank.color+"44"}}>
                  <div style={{fontSize:11,color:subColor,fontFamily:"sans-serif",marginBottom:4}}>{T.accountNumber}</div>
                  <div style={{fontSize:20,fontWeight:700,letterSpacing:2,color:selectedBank.color}}>{selectedBank.account}</div>
                  <div style={{fontSize:12,color:subColor,marginTop:4,fontFamily:"sans-serif"}}>{selectedBank.name}</div>
                </div>
                <input style={S.inp} placeholder={T.amount} type="number" value={form.amount}
                  onChange={e=>setForm(f=>({...f,amount:e.target.value}))} />
                <input style={S.inp} placeholder={T.transactionRef} value={transactionRef}
                  onChange={e=>setTransactionRef(e.target.value)} />
                <div style={{...S.card,textAlign:"center",borderStyle:"dashed",padding:28,cursor:"pointer"}}>
                  <div style={{fontSize:28,marginBottom:6}}>📸</div>
                  <div style={{fontFamily:"sans-serif",fontSize:13,color:subColor}}>{T.uploadScreenshot}</div>
                  <div style={{fontSize:11,color:subColor,fontFamily:"sans-serif",marginTop:4}}>(lien envoyé par WhatsApp)</div>
                </div>
                <button style={S.btn} onClick={submitPayment} disabled={loading||!transactionRef}>
                  {loading?T.loading:T.submitPayment}
                </button>
              </>
            )}

            {payStep===3 && (
              <div style={{textAlign:"center",padding:"60px 0"}}>
                <div style={{fontSize:56,marginBottom:16}}>⏳</div>
                <div style={{...S.title,fontSize:20}}>{T.verifying}</div>
                <div style={{fontSize:52,fontWeight:700,color:theme.accent,marginTop:20}}>{payTimer}</div>
              </div>
            )}
            {payStep===4 && (
              <div style={{textAlign:"center",padding:"60px 0"}}>
                <div style={{fontSize:56,marginBottom:16}}>✅</div>
                <div style={{...S.title,fontSize:20}}>{T.paymentSuccess}</div>
                <div style={{...S.sub,marginTop:8}}>{T.paymentSuccessDesc}</div>
                <button style={{...S.btn,marginTop:28}} onClick={()=>{setSelectedBank(null);setPayStep(1);setActiveTab("subjects");}}>
                  {T.explore}
                </button>
              </div>
            )}

            {/* Payment history */}
            {userPayments.length>0 && (
              <div style={{marginTop:20}}>
                <div style={{fontSize:12,fontFamily:"sans-serif",color:subColor,marginBottom:10,letterSpacing:1,textTransform:"uppercase"}}>
                  Historique
                </div>
                {userPayments.map(p => (
                  <div key={p.id} style={{...S.card,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                    <div>
                      <div style={{fontSize:14,fontWeight:600,fontFamily:"sans-serif"}}>{p.method} · {p.amount} MRU</div>
                      <div style={{fontSize:11,color:subColor,fontFamily:"sans-serif",marginTop:2}}>
                        {new Date(p.submitted_at).toLocaleDateString()}
                      </div>
                    </div>
                    <div style={{fontSize:12,fontFamily:"sans-serif",color:p.status==="validated"?"#4ADE80":p.status==="rejected"?"#F87171":theme.accent}}>
                      {p.status==="validated"?T.paymentValidated:p.status==="rejected"?T.paymentRejected:T.paymentPending}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* ══ SETTINGS TAB ══════════════════════════════════════════════════════ */}
        {activeTab==="settings" && (
          <>
            <div style={S.head}>
              <div style={S.title}>{T.settings}</div>
            </div>

            {/* Profile */}
            <div style={{...S.card,display:"flex",alignItems:"center",gap:14,marginBottom:20}}>
              <div style={{width:50,height:50,borderRadius:"50%",background:theme.accent+"33",border:`2px solid ${theme.accent}`,
                display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,fontWeight:700,color:theme.accent}}>
                {profile?.first_name?.[0]?.toUpperCase() || "?"}
              </div>
              <div>
                <div style={{fontWeight:700,fontSize:16}}>{profile?.first_name} {profile?.last_name}</div>
                <div style={{fontSize:12,color:subColor,fontFamily:"sans-serif"}}>{profile?.phone}</div>
                <div style={{...S.tag,marginTop:4}}>BAC : {profile?.bac_type}</div>
              </div>
            </div>

            {/* Theme */}
            <div style={{marginBottom:20}}>
              <div style={{fontSize:12,fontFamily:"sans-serif",color:subColor,marginBottom:10,letterSpacing:1,textTransform:"uppercase"}}>{T.theme}</div>
              <div style={{display:"flex",gap:8}}>
                {THEMES.map(th => (
                  <div key={th.id} onClick={()=>setTheme(th)}
                    style={{flex:1,height:44,borderRadius:10,background:th.bg,cursor:"pointer",
                      border:`2px solid ${theme.id===th.id?th.accent:"transparent"}`,
                      display:"flex",alignItems:"center",justifyContent:"center"}}>
                    <div style={{width:10,height:10,borderRadius:"50%",background:th.accent}}/>
                  </div>
                ))}
              </div>
            </div>

            {/* Language */}
            <div style={{marginBottom:20}}>
              <div style={{fontSize:12,fontFamily:"sans-serif",color:subColor,marginBottom:10,letterSpacing:1,textTransform:"uppercase"}}>{T.chooseLanguage}</div>
              <div style={{display:"flex",gap:8}}>
                {[{c:"fr",l:"FR"},{c:"ar",l:"ع"},{c:"en",l:"EN"}].map(({c,l}) => (
                  <button key={c} onClick={async()=>{ setLang(c); if(profile) await sb.updateUser(profile.id,{language:c}); }}
                    style={{flex:1,padding:11,borderRadius:9,border:`1.5px solid ${lang===c?theme.accent:theme.border}`,
                      background:lang===c?theme.accent+"22":theme.card,color:lang===c?theme.accent:textColor,
                      cursor:"pointer",fontWeight:700,fontSize:14}}>
                    {l}
                  </button>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div style={{...S.card,marginBottom:20}}>
              <div style={{fontSize:12,fontFamily:"sans-serif",color:subColor,marginBottom:12,letterSpacing:1,textTransform:"uppercase"}}>Statistiques</div>
              <div style={{display:"flex",gap:12}}>
                <div style={{flex:1,textAlign:"center"}}>
                  <div style={{fontSize:24,fontWeight:700,color:theme.accent}}>{progress.length}</div>
                  <div style={{fontSize:11,color:subColor,fontFamily:"sans-serif",marginTop:4}}>Chapitres</div>
                </div>
                <div style={{flex:1,textAlign:"center"}}>
                  <div style={{fontSize:24,fontWeight:700,color:theme.accent}}>
                    {progress.filter(p=>p.video_watched).length}
                  </div>
                  <div style={{fontSize:11,color:subColor,fontFamily:"sans-serif",marginTop:4}}>Vidéos vues</div>
                </div>
                <div style={{flex:1,textAlign:"center"}}>
                  <div style={{fontSize:24,fontWeight:700,color:theme.accent}}>
                    {isPaid?"✓":"✗"}
                  </div>
                  <div style={{fontSize:11,color:subColor,fontFamily:"sans-serif",marginTop:4}}>Abonnement</div>
                </div>
              </div>
            </div>

            <button style={{...S.btnO,color:"#F87171",borderColor:"#F87171"}} onClick={handleLogout}>
              {T.logout}
            </button>
          </>
        )}
      </div>

      {/* Bottom nav */}
      <div style={S.nav}>
        {navTabs.map(tab => (
          <div key={tab.id} onClick={()=>{setActiveTab(tab.id);setActiveSubject(null);setActiveChapter(null);setActiveExam(null);setExamDone(false);setActiveBook(null);}}
            style={{display:"flex",flexDirection:"column",alignItems:"center",gap:3,cursor:"pointer",
              opacity:activeTab===tab.id?1:0.35,transition:"opacity 0.2s"}}>
            <div style={{fontSize:20}}>{tab.icon}</div>
            <div style={{fontSize:9,fontFamily:"sans-serif",color:activeTab===tab.id?theme.accent:subColor,textAlign:"center",lineHeight:1}}>{tab.label}</div>
            {activeTab===tab.id&&<div style={{width:4,height:4,borderRadius:"50%",background:theme.accent}}/>}
          </div>
        ))}
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&display=swap');
        * { box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
        input::placeholder { color:${isDark?"rgba(255,255,255,0.2)":"rgba(0,0,0,0.3)"}; }
        input:focus { border-color:${theme.accent} !important; }
        ::-webkit-scrollbar { display:none; }
        a { color:inherit; }
      `}</style>
    </div>
  );
}
